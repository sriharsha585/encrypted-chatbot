package com.github.bettehem.messenger.tools.listeners;

public interface SettingsListener {

}
