
## **This project has been discontinued. There's a new project based on this, called SecureMessengerAndroid, and can be found at https://gitlab.com/Bettehem/SecureMessengerAndroid** 

# Messenger
An android messenger that only needs a username. Also, there's encryption.
Available on Google Play store for download: https://play.google.com/store/apps/details?id=com.github.bettehem.messenger

The way this messenger app is different from others that i have found, is that no information is collected on users.
For example WhatsApp collects your phone number and contacts among other things.

This app only requires you to select yourself a username and since the app doesn't yet support user images, you need to select a profile emoji, or up to 4 of them, and with a status.

### Starting a chat
To start a chat after creating yourself a profile tap the + button at the bottom of the screen.
Next you need to enter the username of your friend you want to chat with. Note that USERNAMES ARE CASE-SENSITIVE!
Then enter a password you have agreed on with your friend, and press the "Start Chat" -button

After that, a chat request will be sent to your friend, who then has to enter the correct password, and press accept.
A request response will then be sent back to you, and it contains an encrypted version of your username, which will then be compared to your version of it.
If they match, both have entered the same password and the chat is started.
